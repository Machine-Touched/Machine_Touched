## Packages
framer-motion | Complex animations for terminal typing, glitch effects, and transitions
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  terminal: ['"VT323"', "monospace"],
  code: ['"Fira Code"', "monospace"],
}
