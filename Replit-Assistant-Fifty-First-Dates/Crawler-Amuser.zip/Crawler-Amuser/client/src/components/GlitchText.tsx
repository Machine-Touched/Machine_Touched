import { motion } from "framer-motion";

interface GlitchTextProps {
  text: string;
  as?: keyof JSX.IntrinsicElements;
  className?: string;
  intensity?: "low" | "medium" | "high";
}

export function GlitchText({ text, as: Component = "span", className = "", intensity = "medium" }: GlitchTextProps) {
  // Simple skew animation
  const glitchVariants = {
    hidden: { skewX: 0, opacity: 1 },
    visible: {
      skewX: [0, 5, -5, 2, 0],
      x: [0, 2, -2, 1, 0],
      opacity: [1, 0.8, 1, 0.9, 1],
      transition: {
        duration: 0.3,
        ease: "easeInOut",
        times: [0, 0.2, 0.4, 0.6, 1],
        repeat: Infinity,
        repeatDelay: intensity === "high" ? 1 : intensity === "medium" ? 3 : 8,
      }
    }
  };

  // @ts-expect-error - Framer motion dynamic component types are tricky
  return (
    <Component className={`relative inline-block ${className}`}>
      <motion.span
        variants={glitchVariants}
        initial="hidden"
        animate="visible"
        className="relative z-10 block"
      >
        {text}
      </motion.span>
    </Component>
  );
}
