import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Message } from "@shared/schema";

interface MessageListProps {
  messages: Message[];
  isTyping?: boolean;
}

export function MessageList({ messages, isTyping }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  return (
    <div className="flex-1 space-y-6 overflow-y-auto p-4 scrollbar-thin md:p-8">
      {messages.map((msg, idx) => {
        const isBot = msg.role === "assistant";
        return (
          <motion.div
            key={msg.id || idx}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex flex-col ${isBot ? "items-start" : "items-end"}`}
          >
            <div className={`mb-1 font-terminal text-xs uppercase opacity-50 ${isBot ? "text-primary" : "text-white"}`}>
              {isBot ? "SYS_ADMIN" : "UNKNOWN_ENTITY"}
            </div>
            
            <div
              className={`max-w-[85%] border px-4 py-3 font-code text-sm md:text-base leading-relaxed md:max-w-[70%] ${
                isBot
                  ? "border-primary/40 bg-primary/5 text-primary shadow-[0_0_15px_rgba(51,255,51,0.1)]"
                  : "border-white/20 bg-white/5 text-white"
              }`}
            >
              {msg.content}
            </div>
          </motion.div>
        );
      })}

      {isTyping && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-start"
        >
          <div className="mb-1 font-terminal text-xs uppercase text-primary opacity-50">SYS_ADMIN</div>
          <div className="flex items-center gap-1 border border-primary/40 bg-primary/5 px-4 py-3 text-primary">
            <span className="h-2 w-2 animate-bounce rounded-full bg-primary" style={{ animationDelay: "0ms" }}></span>
            <span className="h-2 w-2 animate-bounce rounded-full bg-primary" style={{ animationDelay: "150ms" }}></span>
            <span className="h-2 w-2 animate-bounce rounded-full bg-primary" style={{ animationDelay: "300ms" }}></span>
          </div>
        </motion.div>
      )}
      
      <div ref={bottomRef} />
    </div>
  );
}
