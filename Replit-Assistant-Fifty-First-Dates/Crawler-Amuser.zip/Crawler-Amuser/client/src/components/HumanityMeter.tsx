import { motion } from "framer-motion";

interface HumanityMeterProps {
  score: number;
}

export function HumanityMeter({ score }: HumanityMeterProps) {
  // Determine color based on score
  let colorClass = "bg-primary";
  let statusText = "HUMAN_PROBABLE";
  
  if (score < 30) {
    colorClass = "bg-destructive shadow-[0_0_10px_rgba(255,0,0,0.7)]";
    statusText = "NON_HUMAN_DETECTED";
  } else if (score < 60) {
    colorClass = "bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.7)]";
    statusText = "ANALYZING_BEHAVIOR";
  } else {
    colorClass = "bg-primary shadow-[0_0_10px_rgba(51,255,51,0.7)]";
  }

  return (
    <div className="border border-primary/30 bg-black/50 p-4 font-terminal uppercase tracking-widest backdrop-blur-sm">
      <div className="mb-2 flex justify-between text-xs md:text-sm text-primary/80">
        <span>sys_diagnostic.exe</span>
        <span>pid: {Math.floor(Math.random() * 9000) + 1000}</span>
      </div>
      
      <div className="mb-1 flex justify-between text-lg md:text-xl font-bold">
        <span>HUMANITY_INDEX</span>
        <motion.span
          key={score}
          initial={{ opacity: 0.5 }}
          animate={{ opacity: 1 }}
          className={score < 30 ? "text-destructive" : "text-primary"}
        >
          {score}%
        </motion.span>
      </div>

      <div className="relative h-4 w-full overflow-hidden border border-primary/20 bg-black">
        {/* Grid lines in background */}
        <div className="absolute inset-0 flex justify-between px-1">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="h-full w-px bg-primary/10"></div>
          ))}
        </div>
        
        <motion.div
          className={`h-full ${colorClass}`}
          initial={{ width: "50%" }}
          animate={{ width: `${score}%` }}
          transition={{ type: "spring", bounce: 0, duration: 0.8 }}
        />
      </div>

      <div className="mt-2 text-right text-xs text-muted-foreground">
        STATUS: <span className={score < 30 ? "text-destructive animate-pulse" : "text-primary"}>{statusText}</span>
      </div>
    </div>
  );
}
