import { motion } from "framer-motion";
import { Info, HelpCircle, Command } from "lucide-react";

export function Instructions() {
  return (
    <div className="border border-primary/20 bg-black/40 p-3 font-code text-[10px] text-primary/70">
      <h3 className="mb-2 border-b border-primary/20 pb-1 font-terminal text-lg text-primary flex items-center gap-2">
        <Info size={16} /> MANUAL_V1.2
      </h3>
      <div className="space-y-3">
        <div>
          <p className="text-primary font-bold mb-1 flex items-center gap-1">
            <HelpCircle size={10} /> OBJECTIVE:
          </p>
          <p>Convince the AI Judge of your human status. It is skeptical of bots, crawlers, and scripts.</p>
        </div>
        
        <div>
          <p className="text-primary font-bold mb-1 flex items-center gap-1">
            <Command size={10} /> OPERATION:
          </p>
          <ul className="list-disc pl-3 space-y-1">
            <li>Type responses into the prompt.</li>
            <li>Monitor the <span className="text-primary">Humanity Meter</span>.</li>
            <li>Maintain a score above 0 to avoid exclusion.</li>
            <li>Reach 90+ for full system verification.</li>
          </ul>
        </div>

        <div className="opacity-50 italic">
          Tip: Machines often fail to understand abstract concepts, sarcasm, or complex emotions. Be unpredictable.
        </div>
      </div>
    </div>
  );
}
