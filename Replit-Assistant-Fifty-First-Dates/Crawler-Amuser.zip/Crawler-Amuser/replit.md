# Voight-Kampff 2.0 - Humanity Verification Terminal

## Overview

This is a retro-futuristic chatbot application that simulates a "humanity verification" system inspired by Blade Runner's Voight-Kampff test. Users interact with an AI judge through a CRT-styled terminal interface, answering questions to prove they are human. The AI evaluates responses and adjusts a "humanity score" - reaching 100 means verification, while dropping to 0 results in being flagged as a bot.

The project uses a React frontend with a terminal aesthetic (scanlines, glitch effects, green phosphor styling) and an Express backend that integrates with OpenAI for conversational AI responses.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with custom terminal theme (green CRT aesthetic)
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Animations**: Framer Motion for glitch effects and transitions
- **Build Tool**: Vite with React plugin

The frontend creates an immersive terminal experience with:
- CRT overlay effects (scanlines, noise)
- Custom fonts (VT323 for terminal, Fira Code for code)
- Glitch text animations
- Humanity meter visualization
- Session persistence via localStorage

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with tsx for TypeScript execution
- **API Design**: REST endpoints defined in shared route schemas with Zod validation
- **Build**: esbuild for production bundling, Vite for development

Key backend patterns:
- Shared route definitions between frontend and backend (`shared/routes.ts`)
- Storage abstraction layer for database operations (`server/storage.ts`)
- AI integration modules in `server/replit_integrations/` for chat, image, and batch processing

### Data Storage
- **Database**: PostgreSQL via Drizzle ORM
- **Schema Location**: `shared/schema.ts`
- **Migrations**: Drizzle Kit with `db:push` command

Database tables:
- `sessions`: Tracks user verification sessions with token, humanity score, and verification status
- `messages`: Stores conversation history linked to sessions

### AI Integration
- OpenAI API integration via Replit AI Integrations
- System prompt creates a suspicious, cynical AI personality that evaluates user responses
- **Multilingual Support**: Supports English, Xhosa, Zulu, Tswana, Afrikaans, Chinese, Japanese, Korean, German, and Swedish.
- AI returns structured JSON with score changes, reasons, and response text
- Score system: starts at 50, verified at 100, banned at 0

## External Dependencies

### Third-Party Services
- **OpenAI API**: Used for conversational AI via Replit AI Integrations environment variables (`AI_INTEGRATIONS_OPENAI_API_KEY`, `AI_INTEGRATIONS_OPENAI_BASE_URL`)
- **PostgreSQL**: Database connection via `DATABASE_URL` environment variable

### Key NPM Packages
- `drizzle-orm` / `drizzle-kit`: Database ORM and migrations
- `@tanstack/react-query`: Server state management
- `framer-motion`: Animation library
- `openai`: OpenAI API client
- `zod`: Schema validation
- `shadcn/ui` components via Radix UI primitives

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `AI_INTEGRATIONS_OPENAI_API_KEY`: OpenAI API key
- `AI_INTEGRATIONS_OPENAI_BASE_URL`: OpenAI API base URL (for Replit integration)