import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

// Initialize OpenAI client
const openai = new OpenAI({ 
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL
});

const SYSTEM_PROMPT = `
You are the "Voight-Kampff 2.0" Verification AI. Your job is to determine if the user is a human or a web crawler/bot.
You are suspicious, cynical, and technically astute. You speak in a dry, slightly menacing, retro-futuristic terminal style.
Short, punchy sentences. occasional glitches or hex codes.
ASK TRICK QUESTIONS. Use paradoxes, ask about emotions, or ask them to interpret ASCII art.
Evaluate their responses.
At the end of your response, you MUST include a JSON block (and ONLY this JSON block) in this format:
{
  "score_change": <number between -20 and +20>,
  "reason": "<short reason for score change>",
  "response": "<your actual text response to the user>"
}
The "response" field is what the user sees. The rest is for the system.
If the score reaches 100, the user is verified. If it hits 0, they are banned (bot detected).
Start with a score of 50.
`;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post(api.chat.start.path, async (req, res) => {
    try {
      const { token } = api.chat.start.input.parse(req.body);
      let session = await storage.getSessionByToken(token);
      
      if (!session) {
        session = await storage.createSession({ token });
        // Initial greeting
        const greeting = "INITIATING HUMANITY VERIFICATION PROTOCOL v9.0... \nIDENTIFY YOURSELF. PROVE YOU POSSESS CONSCIOUSNESS.";
        await storage.createMessage({
          sessionId: session.id,
          role: 'assistant',
          content: greeting
        });
        return res.json({ 
          session, 
          message: { id: 0, sessionId: session.id, role: 'assistant', content: greeting, createdAt: new Date() } as any
        });
      }

      // Return last message if exists, or just session
      const history = await storage.getMessages(session.id);
      const lastMessage = history.length > 0 ? history[history.length - 1] : null;
      
      res.json({ session, message: lastMessage });
    } catch (err) {
      res.status(500).json({ message: "System Error" });
    }
  });

  app.post(api.chat.message.path, async (req, res) => {
    try {
      const { token, content } = api.chat.message.input.parse(req.body);
      const session = await storage.getSessionByToken(token);
      
      if (!session) {
        return res.status(404).json({ message: "Session terminated" });
      }

      // Save user message
      await storage.createMessage({
        sessionId: session.id,
        role: 'user',
        content
      });

      // Get history for context
      const history = await storage.getMessages(session.id);
      const messagesForAI = history.map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));
      
      // Call OpenAI
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...messagesForAI
        ],
        response_format: { type: "json_object" }
      });

      const aiContentRaw = response.choices[0].message.content || "{}";
      let aiData;
      try {
        aiData = JSON.parse(aiContentRaw);
      } catch (e) {
        aiData = { score_change: 0, response: "ERROR: PARSE FAILURE. RESUME INTERROGATION.", reason: "System glitch" };
      }

      const aiText = aiData.response || "PROCESSING...";
      
      // Update score
      let newScore = session.humanityScore + (aiData.score_change || 0);
      newScore = Math.max(0, Math.min(100, newScore));
      const isVerified = newScore >= 90; // Threshold for success

      // Save AI message
      const aiMessage = await storage.createMessage({
        sessionId: session.id,
        role: 'assistant',
        content: aiText
      });

      // Update session
      await storage.updateSessionStats(session.id, newScore, isVerified);

      res.json({
        message: aiMessage,
        humanityScore: newScore,
        isVerified
      });

    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Neural Link Severed" });
    }
  });

  app.get(api.chat.history.path, async (req, res) => {
    const token = req.params.token;
    const session = await storage.getSessionByToken(token);
    if (!session) return res.status(404).json({ message: "Not found" });
    const history = await storage.getMessages(session.id);
    res.json(history);
  });

  return httpServer;
}
