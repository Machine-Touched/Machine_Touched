import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";
import { useEffect, useState } from "react";

const STORAGE_KEY = "rtt_session_token";

export function useSessionToken() {
  const [token, setToken] = useState<string | null>(() => 
    localStorage.getItem(STORAGE_KEY)
  );

  const saveToken = (newToken: string) => {
    localStorage.setItem(STORAGE_KEY, newToken);
    setToken(newToken);
  };

  const clearToken = () => {
    localStorage.removeItem(STORAGE_KEY);
    setToken(null);
  };

  return { token, saveToken, clearToken };
}

// GET history
export function useChatHistory(token: string | null) {
  return useQuery({
    queryKey: [api.chat.history.path, token],
    queryFn: async () => {
      if (!token) return [];
      const url = buildUrl(api.chat.history.path, { token });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) {
        if (res.status === 404) return [];
        throw new Error("Failed to fetch history");
      }
      return api.chat.history.responses[200].parse(await res.json());
    },
    enabled: !!token,
  });
}

// POST start session
export function useStartChat() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (token: string) => {
      const res = await fetch(api.chat.start.path, {
        method: api.chat.start.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to start session");
      return api.chat.start.responses[200].parse(await res.json());
    },
    onSuccess: (data, variables) => {
      // Invalidate history query so it fetches the new initial message
      queryClient.invalidateQueries({ queryKey: [api.chat.history.path, variables] });
    },
  });
}

// POST message
export function useSendMessage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ token, content }: { token: string; content: string }) => {
      const res = await fetch(api.chat.message.path, {
        method: api.chat.message.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, content }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to send message");
      return api.chat.message.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.chat.history.path, variables.token] });
    },
  });
}
