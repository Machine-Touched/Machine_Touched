import { motion } from "framer-motion";
import { Info, HelpCircle, Command } from "lucide-react";

interface Content {
  title: string;
  objective_label: string;
  objective_text: string;
  operation_label: string;
  operation_list: string[];
  tip: string;
}

const contentMap: Record<string, Content> = {
  en: {
    title: "MANUAL_V1.3",
    objective_label: "OBJECTIVE:",
    objective_text: "Convince the AI Judge of your human status. It is skeptical of bots, crawlers, and scripts.",
    operation_label: "OPERATION:",
    operation_list: [
      "Type responses into the prompt.",
      "Monitor the Humanity Meter.",
      "Maintain a score above 0 to avoid exclusion.",
      "Reach 90+ for full system verification."
    ],
    tip: "Tip: Machines often fail to understand abstract concepts, sarcasm, or complex emotions. Be unpredictable."
  },
  xh: {
    title: "INCWADI_YEMIYALELO_V1.3",
    objective_label: "INJONGO:",
    objective_text: "Qinisekisa iJaji le-AI ukuba ungumntu. Ithandabuza iibhothi, ii-crawlers, kunye nezikripthi.",
    operation_label: "UKUSEBENZA:",
    operation_list: [
      "Bhala iimpendulo kwi-prompt.",
      "Jonga i-Humanity Meter.",
      "Gcina inqaku elingentla ko-0 ukuze ungaphandle.",
      "Fikelela kuma-90+ ukuze uqinisekiswe ngokupheleleyo."
    ],
    tip: "Icebiso: Oomatshini badla ngokungaphumeleli ukuqonda iingqikelelo ezingekhoyo, uqhulo, okanye iimvakalelo ezinzima. Ungaqikeleleki."
  },
  zu: {
    title: "IMANUWALI_V1.3",
    objective_label: "INHLOSO:",
    objective_text: "Qinisekisa iJaji le-AI ukuthi ungumuntu. Inokungabaza ngama-bots, ama-crawlers, nama-scripts.",
    operation_label: "UKUSETSHENZISWA:",
    operation_list: [
      "Bhala izimpendulo ku-prompt.",
      "Gada i-Humanity Meter.",
      "Gcina amaphuzu angaphezu kuka-0 ukuze ugweme ukukhishwa.",
      "Finyelela ku-90+ ukuze uqinisekiswe ngokugcwele."
    ],
    tip: "Ithiphu: Imishini ivame ukwehluleka ukuqonda imiqondo engaqondakali, ukubhuqa, noma imizwa eyinkimbinkimbi. Ungabikezeleki."
  },
  tn: {
    title: "BUKA_YA_DITAELO_V1.3",
    objective_label: "MAIKEMISETSO:",
    objective_text: "Tlhomamisa Moatlhodi wa AI gore o motho. O belaela di-bot, di-crawler, le di-script.",
    operation_label: "TIRO:",
    operation_list: [
      "Kwala dikarabo mo go prompt.",
      "Ela tlhoko Humanity Meter.",
      "Boloka dintlha tse di fetang 0 go tila go ntshiwa.",
      "Fitlhelela 90+ go netefatswa ka botlalo."
    ],
    tip: "Keletso: Mechine gantsi e palelwa ke go tlhaloganya megopolo e e seng ya mmatota, tshunyo, kgotsa maikutlo a a raraaneng. Se nne yo o bonolo go bonelwa pele."
  },
  af: {
    title: "HANDLEIDING_V1.3",
    objective_label: "DOELWIT:",
    objective_text: "Oortuig die AI-regter van jou menslike status. Dit is skepties oor bots, crawlers en skrifte.",
    operation_label: "OPERASIE:",
    operation_list: [
      "Tik antwoorde in die boks.",
      "Monitor die Menslikheidsmeter.",
      "Hou 'n telling bo 0 om uitsluiting te vermy.",
      "Bereik 90+ vir volledige stelselverifikasie."
    ],
    tip: "Wenk: Masjiene faal dikwels om abstrakte konsepte, sarkasme of komplekse emosies te verstaan. Wees onvoorspelbaar."
  },
  zh: {
    title: "使用手册_V1.3",
    objective_label: "目标：",
    objective_text: "说服AI法官你的真实人类身份。它对机器人、爬虫和脚本持怀疑态度。",
    operation_label: "操作：",
    operation_list: [
      "在提示符中输入回复。",
      "监控人性计量表。",
      "保持分数在0以上以避免被排除。",
      "达到90+分以获得完整系统验证。"
    ],
    tip: "提示：机器通常无法理解抽象概念、讽刺或复杂情感。请保持不可预测性。"
  },
  ja: {
    title: "マニュアル_V1.3",
    objective_label: "目的：",
    objective_text: "AIジャッジにあなたの人間性を証明してください。AIはボット、クローラー、スクリプトに対して懐疑的です。",
    operation_label: "操作：",
    operation_list: [
      "プロンプトに回答を入力してください。",
      "人間性メーターを監視してください。",
      "除外を避けるため、スコアを0以上に維持してください。",
      "完全なシステム認証のために90点以上を目指してください。"
    ],
    tip: "ヒント：機械は抽象的な概念、皮肉、または複雑な感情を理解できないことがよくあります。予測不能であってください。"
  },
  ko: {
    title: "매뉴얼_V1.3",
    objective_label: "목표:",
    objective_text: "AI 판사에게 당신의 인간성을 증명하십시오. AI는 봇, 크롤러 및 스크립트를 의심합니다.",
    operation_label: "조작:",
    operation_list: [
      "프롬프트에 응답을 입력하십시오.",
      "인간성 미터를 모니터링하십시오.",
      "배제되지 않도록 점수를 0점 이상으로 유지하십시오.",
      "전체 시스템 인증을 위해 90점 이상을 달성하십시오."
    ],
    tip: "팁: 기계는 종종 추상적인 개념, 비꼬기 또는 복잡한 감정을 이해하지 못합니다. 예측 불가능하게 행동하십시오."
  },
  de: {
    title: "HANDBUCH_V1.3",
    objective_label: "ZIEL:",
    objective_text: "Überzeugen Sie den KI-Richter von Ihrem menschlichen Status. Er ist skeptisch gegenüber Bots, Crawlern und Skripten.",
    operation_label: "BETRIEB:",
    operation_list: [
      "Geben Sie Antworten in das Feld ein.",
      "Überwachen Sie die Menschlichkeitsanzeige.",
      "Halten Sie die Punktzahl über 0, um einen Ausschluss zu vermeiden.",
      "Erreichen Sie 90+ für eine vollständige Systemverifizierung."
    ],
    tip: "Tipp: Maschinen scheitern oft daran, abstrakte Konzepte, Sarkasmus oder komplexe Emotionen zu verstehen. Seien Sie unvorhersehbar."
  },
  sv: {
    title: "MANUAL_V1.3",
    objective_label: "MÅL:",
    objective_text: "Övertyga AI-domaren om din mänskliga status. Den är skeptisk mot bottar, sökrobotar och skript.",
    operation_label: "DRIFT:",
    operation_list: [
      "Skriv svar i rutan.",
      "Övervaka mänsklighetsmätaren.",
      "Håll en poäng över 0 för att undvika uteslutning.",
      "Nå 90+ för fullständig systemverifiering."
    ],
    tip: "Tips: Maskiner misslyckas ofta med att förstå abstrakta koncept, sarkasm eller komplexa känslor. Var oförutsägbar."
  }
};

export function Instructions({ lang = "en" }: { lang?: string }) {
  const content = contentMap[lang] || contentMap.en;

  return (
    <div className="border border-primary/20 bg-black/40 p-3 font-code text-[10px] text-primary/70">
      <h3 className="mb-2 border-b border-primary/20 pb-1 font-terminal text-lg text-primary flex items-center gap-2">
        <Info size={16} /> {content.title}
      </h3>
      <div className="space-y-3">
        <div>
          <p className="text-primary font-bold mb-1 flex items-center gap-1">
            <HelpCircle size={10} /> {content.objective_label}
          </p>
          <p>{content.objective_text}</p>
        </div>
        
        <div>
          <p className="text-primary font-bold mb-1 flex items-center gap-1">
            <Command size={10} /> {content.operation_label}
          </p>
          <ul className="list-disc pl-3 space-y-1">
            {content.operation_list.map((item, i) => (
              <li key={i}>{item}</li>
            ))}
          </ul>
        </div>

        <div className="opacity-50 italic">
          {content.tip}
        </div>
      </div>
    </div>
  );
}
