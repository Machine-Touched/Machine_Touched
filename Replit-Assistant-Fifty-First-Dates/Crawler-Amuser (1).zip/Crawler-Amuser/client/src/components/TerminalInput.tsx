import { useState, useRef, useEffect } from "react";
import { CornerDownLeft } from "lucide-react";

interface TerminalInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

export function TerminalInput({ onSend, disabled }: TerminalInputProps) {
  const [value, setValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus logic
  useEffect(() => {
    if (!disabled) {
      inputRef.current?.focus();
    }
  }, [disabled]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value.trim() && !disabled) {
      onSend(value);
      setValue("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative mt-4 flex items-center gap-2 border-t border-primary/20 bg-black/80 p-4 backdrop-blur">
      <span className="animate-pulse font-terminal text-xl text-primary">{">"}</span>
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        disabled={disabled}
        className="flex-1 bg-transparent font-code text-base text-primary placeholder:text-primary/30 focus:outline-none disabled:opacity-50"
        placeholder={disabled ? "TRANSMISSION_LOCKED..." : "ENTER_RESPONSE..."}
        autoComplete="off"
        spellCheck={false}
      />
      <button
        type="submit"
        disabled={!value.trim() || disabled}
        className="group relative overflow-hidden rounded-sm border border-primary/50 px-4 py-2 font-terminal uppercase text-primary transition-colors hover:bg-primary/10 disabled:opacity-30 disabled:hover:bg-transparent"
      >
        <span className="relative z-10 flex items-center gap-2">
          SEND <CornerDownLeft size={16} />
        </span>
      </button>
    </form>
  );
}
