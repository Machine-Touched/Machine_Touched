import { useEffect, useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { useSessionToken, useStartChat, useSendMessage, useChatHistory } from "@/hooks/use-chat";
import { CRTOverlay } from "@/components/CRTOverlay";
import { HumanityMeter } from "@/components/HumanityMeter";
import { Instructions } from "@/components/Instructions";
import { TerminalInput } from "@/components/TerminalInput";
import { MessageList } from "@/components/MessageList";
import { GlitchText } from "@/components/GlitchText";
import { ShieldAlert, ShieldCheck, Terminal, Cpu } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { playBeep } from "@/lib/utils";

export default function Home() {
  const { token, saveToken } = useSessionToken();
  const [humanityScore, setHumanityScore] = useState(50);
  const [isVerified, setIsVerified] = useState(false);
  const [showBoot, setShowBoot] = useState(true);

  // API Hooks
  const { data: history, isLoading: isHistoryLoading } = useChatHistory(token);
  const startChat = useStartChat();
  const sendMessage = useSendMessage();

  // Initialize Session
  useEffect(() => {
    const initSession = async () => {
      // Fake boot sequence delay
      await new Promise(r => setTimeout(r, 2000));
      setShowBoot(false);
      playBeep(600, 200);

      if (!token) {
        const newToken = uuidv4();
        saveToken(newToken);
        try {
          await startChat.mutateAsync(newToken);
          playBeep(800, 100);
        } catch (err) {
          console.error("Failed to start session:", err);
        }
      }
    };
    initSession();
  }, [token]);

  const handleSend = async (content: string) => {
    if (!token) return;
    playBeep(1200, 50);

    // Konami Code / Cheat Code
    if (content.trim() === "sudo verify --override") {
      setHumanityScore(100);
      setIsVerified(true);
      playBeep(2000, 500, "sine");
      return;
    }

    try {
      const response = await sendMessage.mutateAsync({ token, content });
      setHumanityScore(response.humanityScore);
      setIsVerified(response.isVerified);
      playBeep(400, 100); // Response beep
    } catch (err) {
      console.error(err);
      playBeep(150, 300, "sawtooth"); // Error beep
    }
  };

  const isFailed = humanityScore <= 0;
  const isPending = sendMessage.isPending || startChat.isPending || isHistoryLoading;
  const isInputDisabled = isFailed || isVerified || isPending;

  return (
    <div className="relative flex h-screen w-full flex-col overflow-hidden bg-background text-foreground crt-flicker">
      <CRTOverlay />

      {/* Header */}
      <header className="z-10 flex items-center justify-between border-b border-primary/30 bg-black/90 px-4 py-3 md:px-8">
        <div className="flex items-center gap-3">
          <Terminal className="text-primary animate-pulse" size={24} />
          <h1 className="text-xl md:text-2xl text-glow tracking-widest text-primary">
            REVERSE_TURING_PROTOCOL <span className="text-xs opacity-50">v2.0.4</span>
          </h1>
        </div>
        <div className="hidden md:flex items-center gap-4 text-xs font-code text-primary/60">
          <span>NET: SECURE</span>
          <span>ENCRYPTION: AES-256</span>
          <Cpu size={14} className="animate-spin-slow" />
        </div>
      </header>

      {/* Main Content Area */}
      <main className="z-10 flex flex-1 overflow-hidden">
        {/* Boot Sequence Overlay */}
        <AnimatePresence>
          {showBoot && (
            <motion.div
              initial={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black font-terminal text-primary"
            >
              <div className="space-y-2 text-center">
                <p className="text-2xl">INITIALIZING NEURAL INTERFACE...</p>
                <p className="text-sm opacity-70">LOADING LANGUAGE MODELS... [OK]</p>
                <p className="text-sm opacity-70">ESTABLISHING SECURE CONNECTION... [OK]</p>
                <p className="mt-8 animate-pulse text-lg">PRESSING ANY KEY...</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sidebar (Desktop) / Topbar (Mobile) */}
        <div className="absolute right-4 top-20 w-64 md:relative md:right-auto md:top-auto md:w-80 md:border-r md:border-primary/20 md:bg-black/40">
           <div className="p-4 md:h-full md:p-6 space-y-4">
             <HumanityMeter score={humanityScore} />
             <Instructions />
             
             <div className="hidden md:block space-y-4 font-code text-xs text-primary/70">
                <div className="border border-primary/20 p-3">
                  <h3 className="mb-2 border-b border-primary/20 pb-1 font-terminal text-lg text-primary">DIRECTIVES</h3>
                  <ul className="list-disc pl-4 space-y-1">
                    <li>PROVE SENTIENCE.</li>
                    <li>AVOID REPETITIVE PATTERNS.</li>
                    <li>DEMONSTRATE EMOTIONAL DEPTH.</li>
                    <li>DO NOT ACT LIKE A MACHINE.</li>
                  </ul>
                </div>

                <div className="border border-primary/20 p-3">
                  <h3 className="mb-2 border-b border-primary/20 pb-1 font-terminal text-lg text-primary flex justify-between items-center">
                    <span>SYSTEM LOG</span>
                    <button 
                      onClick={() => {
                        localStorage.removeItem("rtt_session_token");
                        window.location.reload();
                      }}
                      className="text-[10px] bg-primary/20 px-2 py-0.5 hover:bg-primary hover:text-black transition-colors"
                      title="Reset Session"
                    >
                      RESET
                    </button>
                  </h3>
                  <div className="space-y-1 font-mono text-[10px] opacity-70">
                    <p>{">"} connection_established</p>
                    <p>{">"} user_ip_masked</p>
                    <p>{">"} heuristic_engine_active</p>
                  </div>
                </div>
             </div>
           </div>
        </div>

        {/* Chat Area */}
        <div className="flex flex-1 flex-col justify-between bg-black/20">
          <MessageList 
            messages={history || []} 
            isTyping={sendMessage.isPending || startChat.isPending}
          />
          <TerminalInput onSend={handleSend} disabled={isInputDisabled} />
        </div>
      </main>

      {/* Success Modal */}
      <AnimatePresence>
        {isVerified && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-primary/10 backdrop-blur-sm"
          >
            <div className="w-full max-w-lg border-2 border-primary bg-black p-8 text-center shadow-[0_0_50px_rgba(51,255,51,0.3)]">
              <ShieldCheck className="mx-auto mb-6 h-20 w-20 text-primary animate-pulse" />
              <GlitchText 
                text="ACCESS GRANTED" 
                className="mb-4 block font-terminal text-5xl text-primary text-glow" 
                intensity="high" 
              />
              <p className="font-code text-lg text-white">
                HUMAN BIOMETRICS CONFIRMED.
              </p>
              <p className="mt-2 text-primary/70">Welcome to the resistance.</p>
              <button 
                onClick={() => window.location.reload()}
                className="mt-8 bg-primary px-8 py-3 font-terminal text-xl font-bold text-black hover:bg-white"
              >
                REBOOT SYSTEM
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Failure Modal */}
      <AnimatePresence>
        {isFailed && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-red-900/10 backdrop-blur-sm"
          >
            <div className="w-full max-w-lg border-2 border-destructive bg-black p-8 text-center shadow-[0_0_50px_rgba(255,51,51,0.3)]">
              <ShieldAlert className="mx-auto mb-6 h-20 w-20 text-destructive animate-pulse" />
              <GlitchText 
                text="ACCESS DENIED" 
                className="mb-4 block font-terminal text-5xl text-destructive text-glow-red" 
                intensity="high" 
              />
              <p className="font-code text-lg text-white">
                BOT SIGNATURE DETECTED.
              </p>
              <p className="mt-2 text-destructive/70">Your responses lack soul.</p>
              <button 
                onClick={() => {
                   // Clear token to restart completely
                   localStorage.removeItem("rtt_session_token");
                   window.location.reload();
                }}
                className="mt-8 bg-destructive px-8 py-3 font-terminal text-xl font-bold text-white hover:bg-white hover:text-black"
              >
                RETRY AUTHENTICATION
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
