# Deployment Guide: Reverse Turing Protocol

To run this application on your own website/server, follow these steps:

## 1. Prerequisites
- **Node.js**: Version 18 or higher.
- **PostgreSQL**: A running database instance.
- **OpenAI API Key**: Required for the AI Judge.

## 2. Files to Include
- All files from the project repository (or the downloaded ZIP).
- Key directories: `client/`, `server/`, `shared/`.

## 3. Environment Variables
Create a `.env` file on your server with the following:
```env
DATABASE_URL=postgres://user:password@host:port/dbname
AI_INTEGRATIONS_OPENAI_API_KEY=your_openai_key
AI_INTEGRATIONS_OPENAI_BASE_URL=https://api.openai.com/v1
SESSION_SECRET=a_random_secure_string
```

## 4. Installation & Build
Run these commands in your project root:
```bash
# Install dependencies
npm install

# Build the frontend and backend
npm run build

# Push database schema (using Drizzle)
npx drizzle-kit push
```

## 5. Running the Application
Use a process manager like **PM2** to keep the app running:
```bash
# Start with PM2
pm2 start "npm run start" --name "reverse-turing"
```
The app will default to port 5000. You can then use a reverse proxy (like Nginx) to map your domain to this port.

## 6. Static Hosting Note
This app **cannot** be hosted on static platforms like GitHub Pages because it requires a Node.js backend and a database to store messages and calculate scores.
