import { useMouseTracking } from '../hooks/use-mouse-tracking';
import { useWebSocket } from '../hooks/use-websocket';
import { useDeviceSensors } from '../hooks/use-device-sensors';
import { NeuralCanvas } from '../components/neural-canvas';
import { AuthHeader } from '../components/auth-header';
import { BiometricPanel } from '../components/biometric-panel';
import { SymbiosisDetector } from '../components/symbiosis-detector';
import { SpecimenTracker } from '../components/specimen-tracker';
import { ProximitySensors } from '../components/proximity-sensors';
import { DataStream } from '../components/data-stream';
import { SystemLogs } from '../components/system-logs';
import { useEffect, useState } from 'react';
import type { Specimen } from '@shared/schema';

export default function Laboratory() {
  const { position, metrics, clickHistory, getClickWaveformPoints } = useMouseTracking();
  const { isConnected, sessionId, sendBiometricUpdate, sendSpecimenInteraction } = useWebSocket();
  const { orientation, motion } = useDeviceSensors();
  const [symbiosisLevel, setSymbiosisLevel] = useState(0);

  // Send biometric updates via WebSocket
  useEffect(() => {
    if (isConnected && sessionId) {
      const biometricData = {
        mouseVelocity: metrics.velocity,
        hesitationTime: metrics.hesitationTime,
        clickPattern: metrics.clickPattern,
        symbiosisLevel,
        pathwayCount: metrics.pathwayCount,
        deviceOrientation: {
          alpha: orientation.alpha,
          beta: orientation.beta,
          gamma: orientation.gamma
        },
        deviceMotion: {
          x: motion.x,
          y: motion.y,
          z: motion.z
        }
      };

      sendBiometricUpdate(biometricData);
    }
  }, [
    metrics.velocity, 
    metrics.hesitationTime, 
    metrics.clickPattern, 
    symbiosisLevel,
    metrics.pathwayCount,
    orientation,
    motion,
    isConnected,
    sessionId,
    sendBiometricUpdate
  ]);

  const handleSpecimenSelect = (specimen: Specimen) => {
    if (isConnected) {
      sendSpecimenInteraction({
        specimenId: specimen.specimenId,
        classification: specimen.classification,
        status: specimen.status,
        timestamp: Date.now()
      });
    }
  };

  return (
    <div className="min-h-screen relative">
      {/* Neural Pathway Canvas */}
      <NeuralCanvas 
        mousePosition={position}
        pathwayCount={metrics.pathwayCount}
        isActive={isConnected}
      />
      
      {/* Main Laboratory Interface */}
      <div className="min-h-screen p-4 grid grid-cols-12 grid-rows-6 gap-4 relative z-30">
        
        {/* Header Authentication Panel */}
        <AuthHeader 
          isConnected={isConnected}
          sessionId={sessionId}
        />

        {/* Biometric Analysis Panel */}
        <BiometricPanel 
          velocity={metrics.velocity}
          hesitationTime={metrics.hesitationTime}
          clickPattern={metrics.clickPattern}
          clickWaveformPoints={getClickWaveformPoints()}
        />

        {/* Central Symbiosis Detector */}
        <SymbiosisDetector 
          velocity={metrics.velocity}
          hesitationTime={metrics.hesitationTime}
          clickCount={clickHistory.length}
          pathwayCount={metrics.pathwayCount}
          onSymbiosisChange={setSymbiosisLevel}
        />

        {/* Specimen Tracker */}
        <SpecimenTracker 
          onSpecimenSelect={handleSpecimenSelect}
        />

        {/* Proximity Sensors */}
        <ProximitySensors />

        {/* Data Stream Panel */}
        <DataStream 
          pathwayCount={metrics.pathwayCount}
          symbiosisLevel={symbiosisLevel}
        />

        {/* System Logs */}
        <SystemLogs 
          sessionId={sessionId}
          pathwayCount={metrics.pathwayCount}
        />
      </div>
    </div>
  );
}
