interface BiometricPanelProps {
  velocity: number;
  hesitationTime: number;
  clickPattern: string;
  clickWaveformPoints: string;
}

export function BiometricPanel({ 
  velocity, 
  hesitationTime, 
  clickPattern, 
  clickWaveformPoints 
}: BiometricPanelProps) {
  const velocityPercentage = Math.min(velocity / 5, 100);
  const hesitationPercentage = Math.min(hesitationTime * 20, 100);

  return (
    <div className="col-span-4 row-span-2 lab-panel rounded-lg p-4">
      <h3 className="text-lg font-semibold mb-4 text-secondary matrix-text">
        <i className="fas fa-heartbeat mr-2"></i>BIOMETRIC ANALYSIS
      </h3>
      <div className="space-y-4">
        <div className="border border-border rounded p-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm">Mouse Velocity</span>
            <span className="text-primary font-bold" data-testid="mouse-velocity">
              {Math.round(velocity)} px/s
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${velocityPercentage}%` }}
              data-testid="velocity-bar"
            />
          </div>
        </div>
        
        <div className="border border-border rounded p-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm">Cursor Hesitation</span>
            <span className="text-accent font-bold" data-testid="hesitation-level">
              {hesitationTime.toFixed(1)}s
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-accent h-2 rounded-full transition-all duration-300"
              style={{ width: `${hesitationPercentage}%` }}
              data-testid="hesitation-bar"
            />
          </div>
        </div>
        
        <div className="border border-border rounded p-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm">Click Pattern</span>
            <span className="text-secondary font-bold" data-testid="click-pattern">
              {clickPattern}
            </span>
          </div>
          <svg className="w-full h-12" viewBox="0 0 300 50" data-testid="click-waveform">
            <polyline 
              points={clickWaveformPoints} 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              className="text-secondary animate-data-stream"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}
