import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { Specimen } from '@shared/schema';

interface SpecimenTrackerProps {
  onSpecimenSelect?: (specimen: Specimen) => void;
}

export function SpecimenTracker({ onSpecimenSelect }: SpecimenTrackerProps) {
  const [currentSpecimen, setCurrentSpecimen] = useState<Specimen | null>(null);

  const { data: specimens = [] } = useQuery<Specimen[]>({
    queryKey: ['/api/specimens'],
  });

  useEffect(() => {
    if (specimens.length > 0 && !currentSpecimen) {
      setCurrentSpecimen(specimens[0]);
    }
  }, [specimens, currentSpecimen]);

  const handleSpecimenHover = (specimen: Specimen) => {
    setCurrentSpecimen(specimen);
    onSpecimenSelect?.(specimen);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ACTIVE': return 'text-primary';
      case 'SCANNING': return 'text-accent';
      case 'DORMANT': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getSpecimenTypeFromId = (specimenId: string) => {
    const types = ['DIGITAL_CLOTHING_LOUSE', 'DATA_PARASITE', 'NEURAL_SYMBIONT', 'CYBER_ORGANISM'];
    const id = parseInt(specimenId.replace('SP-', '')) || 1;
    return types[(id - 1) % types.length];
  };

  return (
    <div className="col-span-4 row-span-2 lab-panel rounded-lg p-4">
      <h3 className="text-lg font-semibold mb-4 text-accent matrix-text">
        <i className="fas fa-bug mr-2"></i>SPECIMEN TRACKER
      </h3>
      <div className="grid grid-cols-4 gap-2 mb-4">
        {specimens.slice(0, 8).map((specimen) => (
          <div
            key={specimen.id}
            className="specimen-item border border-border rounded p-2 text-center text-xs hover:specimen-glow transition-all cursor-pointer"
            onMouseEnter={() => handleSpecimenHover(specimen)}
            data-testid={`specimen-${specimen.specimenId}`}
          >
            <div className="text-primary font-bold">{specimen.specimenId}</div>
            <div className={getStatusColor(specimen.status)}>{specimen.status}</div>
          </div>
        ))}
      </div>
      <div className="border-t border-border pt-3">
        <div className="text-sm">
          <span className="text-muted-foreground">Current Subject:</span>
          <span className="text-secondary font-bold ml-2" data-testid="current-specimen">
            {currentSpecimen?.specimenId || 'SPECIMEN-001'}
          </span>
        </div>
        <div className="text-xs text-muted-foreground mt-1">
          Classification: 
          <span className="text-accent ml-1" data-testid="specimen-type">
            {currentSpecimen ? 
              currentSpecimen.classification : 
              getSpecimenTypeFromId('SP-001')
            }
          </span>
        </div>
        {currentSpecimen?.behaviorData && (
          <div className="text-xs text-muted-foreground mt-1">
            Symbiosis: 
            <span className="text-primary ml-1">
              {currentSpecimen.behaviorData.symbiosisLevel?.toFixed(1) || '0.0'}%
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
