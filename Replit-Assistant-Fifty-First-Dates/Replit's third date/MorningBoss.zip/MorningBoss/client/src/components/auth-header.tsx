import { useState, useEffect } from 'react';

interface AuthHeaderProps {
  isConnected: boolean;
  sessionId: string | null;
}

export function AuthHeader({ isConnected, sessionId }: AuthHeaderProps) {
  const [systemStatus, setSystemStatus] = useState('SCANNING FOR DIGITAL CRUMBS...');
  const [operationalMode, setOperationalMode] = useState('ASSEMBLING');

  useEffect(() => {
    const updateStatus = () => {
      const statuses = [
        'SCANNING FOR DIGITAL CRUMBS...',
        'ANALYZING BEHAVIORAL PATTERNS...',
        'MAPPING NEURAL PATHWAYS...',
        'DETECTING CYBERNETIC SIGNATURES...',
        'MONITORING BIOMETRIC ANOMALIES...'
      ];
      
      const modes = ['ASSEMBLING', 'ANALYZING', 'PROCESSING', 'MONITORING'];
      
      setSystemStatus(statuses[Math.floor(Math.random() * statuses.length)]);
      setOperationalMode(modes[Math.floor(Math.random() * modes.length)]);
    };

    const interval = setInterval(updateStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="col-span-12 row-span-1 lab-panel rounded-lg p-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <div className="text-secondary">
          <i className="fas fa-microchip text-2xl"></i>
        </div>
        <div>
          <h1 className="text-xl font-bold matrix-text" data-testid="lab-title">
            MACHINE_TOUCHED LABORATORY
          </h1>
          <p className="text-sm text-muted-foreground">
            robot_password: <span className="text-primary">1</span> | 
            auth_level: <span className="text-accent">advanced</span> | 
            access_granted: <span className="text-primary">true</span>
          </p>
        </div>
      </div>
      <div className="text-right">
        <div className="text-destructive font-bold" data-testid="system-status">
          {systemStatus}
        </div>
        <div className="text-xs text-muted-foreground">
          STATUS: <span data-testid="operational-mode">{operationalMode}</span>
        </div>
        <div className="text-xs text-muted-foreground mt-1">
          CONNECTION: <span className={isConnected ? 'text-primary' : 'text-destructive'}>
            {isConnected ? 'NEURAL_LINK_ACTIVE' : 'ESTABLISHING...'}
          </span>
        </div>
        {sessionId && (
          <div className="text-xs text-accent">
            SESSION: {sessionId.slice(0, 8)}...
          </div>
        )}
      </div>
    </div>
  );
}
