import { useDeviceSensors } from '../hooks/use-device-sensors';

export function ProximitySensors() {
  const { 
    orientation, 
    motion, 
    hasOrientationPermission, 
    hasMotionPermission,
    requestPermissions,
    getOrientationStatus,
    getMotionStatus 
  } = useDeviceSensors();

  const handleRequestPermissions = () => {
    requestPermissions();
  };

  return (
    <div className="col-span-3 row-span-2 lab-panel rounded-lg p-4">
      <h3 className="text-lg font-semibold mb-4 text-destructive matrix-text">
        <i className="fas fa-radar mr-2"></i>PROXIMITY SENSORS
      </h3>
      
      {(hasOrientationPermission === null || hasMotionPermission === null) && (
        <div className="mb-4 p-2 border border-accent rounded">
          <button 
            onClick={handleRequestPermissions}
            className="text-xs text-accent hover:text-accent-foreground transition-colors"
            data-testid="request-permissions"
          >
            [ENABLE_DEVICE_SENSORS]
          </button>
        </div>
      )}
      
      <div className="space-y-3">
        <div className="border border-border rounded p-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm">Device Orientation</span>
            <span className="text-primary" data-testid="orientation-status">
              {getOrientationStatus()}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div>
              α: <span className="text-secondary" data-testid="alpha-value">
                {orientation.alpha !== null ? Math.round(orientation.alpha) + '°' : '0°'}
              </span>
            </div>
            <div>
              β: <span className="text-secondary" data-testid="beta-value">
                {orientation.beta !== null ? Math.round(orientation.beta) + '°' : '0°'}
              </span>
            </div>
            <div>
              γ: <span className="text-secondary" data-testid="gamma-value">
                {orientation.gamma !== null ? Math.round(orientation.gamma) + '°' : '0°'}
              </span>
            </div>
          </div>
        </div>
        
        <div className="border border-border rounded p-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm">Motion Detection</span>
            <span className="text-accent" data-testid="motion-status">
              {getMotionStatus()}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div>
              X: <span className="text-secondary" data-testid="motion-x">
                {motion.x !== null ? motion.x.toFixed(1) : '0'}
              </span>
            </div>
            <div>
              Y: <span className="text-secondary" data-testid="motion-y">
                {motion.y !== null ? motion.y.toFixed(1) : '0'}
              </span>
            </div>
            <div>
              Z: <span className="text-secondary" data-testid="motion-z">
                {motion.z !== null ? motion.z.toFixed(1) : '0'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
