import { useEffect, useState } from 'react';

interface SymbiosisDetectorProps {
  velocity: number;
  hesitationTime: number;
  clickCount: number;
  pathwayCount: number;
  onSymbiosisChange?: (level: number) => void;
}

export function SymbiosisDetector({ 
  velocity, 
  hesitationTime, 
  clickCount, 
  pathwayCount,
  onSymbiosisChange 
}: SymbiosisDetectorProps) {
  const [symbiosisLevel, setSymbiosisLevel] = useState(0);

  useEffect(() => {
    const velocityFactor = Math.min(velocity / 100, 1);
    const hesitationFactor = Math.max(0, 1 - hesitationTime / 5);
    const activityFactor = Math.min(clickCount / 10, 1);
    
    const newLevel = Math.min(
      (velocityFactor * 0.4 + hesitationFactor * 0.3 + activityFactor * 0.3) * 100,
      100
    );
    
    setSymbiosisLevel(newLevel);
    onSymbiosisChange?.(newLevel);
  }, [velocity, hesitationTime, clickCount, onSymbiosisChange]);

  const percentage = Math.round(symbiosisLevel);
  const circumference = 502.65;
  const offset = circumference - (percentage / 100) * circumference;

  const getSymbiosisStatus = () => {
    if (percentage > 75) return 'SYMBIOTIC';
    if (percentage > 50) return 'CONNECTING';
    if (percentage > 25) return 'DETECTING';
    return 'INITIALIZING';
  };

  const getProximitySignal = () => {
    if (percentage > 60) return 'STRONG';
    if (percentage > 30) return 'MODERATE';
    return 'WEAK';
  };

  return (
    <div className="col-span-4 row-span-4 lab-panel rounded-lg p-6 flex flex-col items-center justify-center">
      <h2 className="text-2xl font-bold mb-6 text-center matrix-text text-primary">
        <i className="fas fa-atom mr-3"></i>SYMBIOSIS DETECTOR
      </h2>
      
      {/* Central Circular Display */}
      <div className="relative w-48 h-48 mb-6">
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
          {/* Background Circle */}
          <circle 
            cx="100" 
            cy="100" 
            r="80" 
            fill="none" 
            stroke="rgba(0, 255, 65, 0.2)" 
            strokeWidth="8"
          />
          {/* Progress Circle */}
          <circle 
            cx="100" 
            cy="100" 
            r="80" 
            fill="none" 
            stroke="url(#symbiosisGradient)" 
            strokeWidth="8" 
            strokeLinecap="round" 
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-all duration-700 ease-out"
            data-testid="symbiosis-circle"
          />
          <defs>
            <linearGradient id="symbiosisGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: 'var(--primary)', stopOpacity: 1 }} />
              <stop offset="50%" style={{ stopColor: 'var(--secondary)', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: 'var(--accent)', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl font-bold text-primary" data-testid="symbiosis-percentage">
              {percentage}%
            </div>
            <div className="text-sm text-muted-foreground">CONNECTED</div>
          </div>
        </div>
      </div>
      
      {/* Connection Status */}
      <div className="w-full space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-sm">Neural Pathways</span>
          <span className="text-primary font-bold" data-testid="pathway-count">
            {pathwayCount} active
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm">Proximity Signal</span>
          <span className="text-secondary font-bold" data-testid="proximity-signal">
            {getProximitySignal()}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm">Symbiosis Level</span>
          <span className="text-accent font-bold" data-testid="symbiosis-level">
            {getSymbiosisStatus()}
          </span>
        </div>
      </div>
    </div>
  );
}
