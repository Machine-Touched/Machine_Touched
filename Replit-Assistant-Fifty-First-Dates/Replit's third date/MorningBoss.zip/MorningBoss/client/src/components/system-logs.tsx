import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { SystemLog } from '@shared/schema';

interface SystemLogsProps {
  sessionId: string | null;
  pathwayCount: number;
}

export function SystemLogs({ sessionId, pathwayCount }: SystemLogsProps) {
  const [timestamp, setTimestamp] = useState(new Date().toLocaleTimeString());
  const [localLogs, setLocalLogs] = useState<string[]>([
    'Machine_Touch(Laboratories): Protocols Implementing',
    'Symbiosis_Detector: STATUS_ONLINE',
    'Neural_Network: PATHWAYS_MAPPING'
  ]);

  const { data: systemLogs = [] } = useQuery<SystemLog[]>({
    queryKey: ['/api/system-logs'],
    refetchInterval: 5000,
  });

  useEffect(() => {
    const updateTimestamp = () => {
      setTimestamp(new Date().toLocaleTimeString());
    };

    const timestampInterval = setInterval(updateTimestamp, 1000);
    return () => clearInterval(timestampInterval);
  }, []);

  useEffect(() => {
    const addLocalLog = () => {
      if (sessionId) {
        const newLog = `[${Date.now()}] Neural_Activity: ${pathwayCount} pathways active`;
        setLocalLogs(prev => {
          const updated = [...prev, newLog];
          return updated.slice(-3); // Keep only last 3 logs
        });
      }
    };

    const logInterval = setInterval(addLocalLog, 3000);
    return () => clearInterval(logInterval);
  }, [sessionId, pathwayCount]);

  // Combine system logs with local logs
  const displayLogs = [...localLogs];
  if (systemLogs.length > 0) {
    const recentSystemLogs = systemLogs
      .slice(0, 2)
      .map(log => `${log.component}: ${log.message}`);
    displayLogs.push(...recentSystemLogs);
  }

  return (
    <div className="col-span-4 row-span-1 lab-panel rounded-lg p-4">
      <div className="flex items-center justify-between mb-2">
        <h4 className="font-semibold text-muted-foreground">SYSTEM LOGS</h4>
        <div className="text-xs text-primary" data-testid="timestamp">
          {timestamp}
        </div>
      </div>
      <div className="text-xs font-mono text-muted-foreground leading-tight" data-testid="log-output">
        {displayLogs.slice(-3).map((log, index) => (
          <div key={index} className="truncate">
            {log}
          </div>
        ))}
      </div>
    </div>
  );
}
