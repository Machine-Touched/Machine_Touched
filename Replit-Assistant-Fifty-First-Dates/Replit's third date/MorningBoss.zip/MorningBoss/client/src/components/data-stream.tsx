import { useState, useEffect } from 'react';

const dataStreams = [
  { icon: '🦠', code: '001', message: 'DIGITAL_TRACE_DETECTED', detail: 'cursor_hesitation_0.3s', color: 'text-primary' },
  { icon: '🔍', code: '002', message: 'SCANNING_BEHAVIORAL_PATTERN', detail: 'mouse_velocity_high', color: 'text-secondary' },
  { icon: '⚡', code: '003', message: 'NEURAL_PATHWAY_FORMED', detail: 'connection_strength_0.7', color: 'text-accent' },
  { icon: '⚠️', code: '004', message: 'PROXIMITY_ALERT', detail: 'device_orientation_changed', color: 'text-destructive' },
  { icon: '🧬', code: '005', message: 'SYMBIOSIS_EVENT', detail: 'biometric_sync_detected', color: 'text-primary' },
  { icon: '📊', code: '006', message: 'DATA_PATTERN', detail: 'click_rhythm_analyzed', color: 'text-secondary' },
  { icon: '🔬', code: '007', message: 'SPECIMEN_UPDATE', detail: 'classification_refined', color: 'text-accent' },
  { icon: '🌐', code: '008', message: 'NETWORK_PULSE', detail: 'digital_body_language_read', color: 'text-primary' },
  { icon: '🎯', code: '009', message: 'TARGET_ACQUIRED', detail: 'interaction_pattern_logged', color: 'text-secondary' },
  { icon: '🔄', code: '010', message: 'FEEDBACK_LOOP', detail: 'cybernetic_connection_deepening', color: 'text-accent' },
  { icon: '⚡', code: '011', message: 'ANOMALY_DETECTED', detail: 'unusual_cursor_trajectory', color: 'text-destructive' },
  { icon: '🧠', code: '012', message: 'NEURAL_SYNC', detail: 'thought_pattern_predicted', color: 'text-primary' },
];

interface DataStreamProps {
  pathwayCount: number;
  symbiosisLevel: number;
}

export function DataStream({ pathwayCount, symbiosisLevel }: DataStreamProps) {
  const [currentStreams, setCurrentStreams] = useState(dataStreams);

  useEffect(() => {
    const updateStreams = () => {
      // Generate dynamic data based on activity level
      const activityLevel = Math.max(pathwayCount, symbiosisLevel / 20);
      const streamCount = Math.min(12 + Math.floor(activityLevel), 20);
      
      const baseStreams = [...dataStreams];
      
      // Add dynamic entries based on current activity
      if (pathwayCount > 5) {
        baseStreams.push({
          icon: '🔥',
          code: String(Date.now()).slice(-3),
          message: 'HIGH_ACTIVITY_DETECTED',
          detail: `pathway_count_${pathwayCount}`,
          color: 'text-primary'
        });
      }
      
      if (symbiosisLevel > 50) {
        baseStreams.push({
          icon: '🌟',
          code: String(Date.now()).slice(-3),
          message: 'SYMBIOSIS_THRESHOLD_REACHED',
          detail: `level_${Math.round(symbiosisLevel)}%`,
          color: 'text-accent'
        });
      }
      
      // Shuffle and take the desired count
      const shuffled = baseStreams.sort(() => Math.random() - 0.5).slice(0, streamCount);
      setCurrentStreams(shuffled);
    };

    const interval = setInterval(updateStreams, 3000);
    updateStreams(); // Initial update
    
    return () => clearInterval(interval);
  }, [pathwayCount, symbiosisLevel]);

  return (
    <div className="col-span-5 row-span-2 lab-panel rounded-lg p-4">
      <h3 className="text-lg font-semibold mb-4 text-primary matrix-text">
        <i className="fas fa-stream mr-2"></i>AMBIENT DATA STREAMS
      </h3>
      <div className="data-feed bg-input rounded border" data-testid="data-stream">
        <div className="scrolling-data p-3 text-xs font-mono space-y-1 animate-scroll-up">
          {currentStreams.map((stream, index) => (
            <div key={`${stream.code}-${index}`} className={stream.color}>
              {stream.icon} [{stream.code}] {stream.message}: {stream.detail}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
