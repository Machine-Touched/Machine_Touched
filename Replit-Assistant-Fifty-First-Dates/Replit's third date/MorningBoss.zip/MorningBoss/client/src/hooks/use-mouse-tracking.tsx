import { useState, useEffect, useRef, useCallback } from 'react';

interface MousePosition {
  x: number;
  y: number;
}

interface MouseMetrics {
  velocity: number;
  hesitationTime: number;
  clickPattern: string;
  isMoving: boolean;
  pathwayCount: number;
}

interface ClickEvent {
  timestamp: number;
  position: MousePosition;
}

export function useMouseTracking() {
  const [position, setPosition] = useState<MousePosition>({ x: 0, y: 0 });
  const [metrics, setMetrics] = useState<MouseMetrics>({
    velocity: 0,
    hesitationTime: 0,
    clickPattern: 'STABLE',
    isMoving: false,
    pathwayCount: 0
  });

  const lastPositionRef = useRef<MousePosition>({ x: 0, y: 0 });
  const lastMoveTimeRef = useRef<number>(Date.now());
  const clickHistoryRef = useRef<ClickEvent[]>([]);
  const isMovingRef = useRef<boolean>(false);

  const updateHesitation = useCallback(() => {
    const now = Date.now();
    if (!isMovingRef.current && now - lastMoveTimeRef.current > 100) {
      const hesitationTime = (now - lastMoveTimeRef.current) / 1000;
      setMetrics(prev => ({ ...prev, hesitationTime }));
    } else {
      setMetrics(prev => ({ ...prev, hesitationTime: 0 }));
    }
    isMovingRef.current = false;
  }, []);

  const analyzeClickPattern = useCallback((clickHistory: ClickEvent[]) => {
    if (clickHistory.length < 3) return 'STABLE';

    const intervals = [];
    for (let i = 1; i < clickHistory.length; i++) {
      intervals.push(clickHistory[i].timestamp - clickHistory[i - 1].timestamp);
    }

    const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;

    if (avgInterval < 200) return 'RAPID';
    if (avgInterval > 2000) return 'DELIBERATE';
    return 'RHYTHMIC';
  }, []);

  const handleMouseMove = useCallback((event: MouseEvent) => {
    const newPosition = { x: event.clientX, y: event.clientY };
    
    // Calculate velocity
    const dx = newPosition.x - lastPositionRef.current.x;
    const dy = newPosition.y - lastPositionRef.current.y;
    const velocity = Math.sqrt(dx * dx + dy * dy) * 10; // Scale for display

    setPosition(newPosition);
    setMetrics(prev => ({
      ...prev,
      velocity,
      isMoving: true,
      pathwayCount: Math.floor(velocity / 20)
    }));

    lastPositionRef.current = newPosition;
    lastMoveTimeRef.current = Date.now();
    isMovingRef.current = true;
  }, []);

  const handleClick = useCallback((event: MouseEvent) => {
    const clickEvent: ClickEvent = {
      timestamp: Date.now(),
      position: { x: event.clientX, y: event.clientY }
    };

    clickHistoryRef.current.push(clickEvent);

    // Keep only last 10 clicks
    if (clickHistoryRef.current.length > 10) {
      clickHistoryRef.current.shift();
    }

    const pattern = analyzeClickPattern(clickHistoryRef.current);
    setMetrics(prev => ({ ...prev, clickPattern: pattern }));
  }, [analyzeClickPattern]);

  const createCursorTrail = useCallback((x: number, y: number) => {
    const trail = document.createElement('div');
    trail.className = 'cursor-trail';
    trail.style.left = x + 'px';
    trail.style.top = y + 'px';
    trail.style.position = 'fixed';
    trail.style.pointerEvents = 'none';
    trail.style.zIndex = '9999';
    
    document.body.appendChild(trail);
    
    setTimeout(() => {
      trail.style.opacity = '0';
      trail.style.transition = 'opacity 0.5s ease';
      setTimeout(() => {
        if (trail.parentNode) {
          trail.parentNode.removeChild(trail);
        }
      }, 500);
    }, 100);
  }, []);

  const getClickWaveformPoints = useCallback(() => {
    if (clickHistoryRef.current.length < 2) return '';

    return clickHistoryRef.current.map((click, index) => {
      const x = (index / (clickHistoryRef.current.length - 1)) * 300;
      const interval = index > 0 ? 
        click.timestamp - clickHistoryRef.current[index - 1].timestamp : 1000;
      const y = 25 + Math.sin(interval / 100) * 20;
      return `${x},${y}`;
    }).join(' ');
  }, []);

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('click', handleClick);

    // Hesitation detection interval
    const hesitationInterval = setInterval(updateHesitation, 100);

    // Cursor trail effect
    const trailHandler = (e: MouseEvent) => {
      if (Math.random() < 0.1) { // 10% chance to create trail
        createCursorTrail(e.clientX, e.clientY);
      }
    };
    document.addEventListener('mousemove', trailHandler);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('click', handleClick);
      document.removeEventListener('mousemove', trailHandler);
      clearInterval(hesitationInterval);
    };
  }, [handleMouseMove, handleClick, updateHesitation, createCursorTrail]);

  return {
    position,
    metrics,
    clickHistory: clickHistoryRef.current,
    getClickWaveformPoints
  };
}
