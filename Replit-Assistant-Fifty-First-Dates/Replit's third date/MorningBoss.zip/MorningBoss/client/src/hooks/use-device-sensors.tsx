import { useState, useEffect, useCallback } from 'react';

interface DeviceOrientation {
  alpha: number | null;
  beta: number | null;
  gamma: number | null;
}

interface DeviceMotion {
  x: number | null;
  y: number | null;
  z: number | null;
}

export function useDeviceSensors() {
  const [orientation, setOrientation] = useState<DeviceOrientation>({
    alpha: null,
    beta: null,
    gamma: null
  });

  const [motion, setMotion] = useState<DeviceMotion>({
    x: null,
    y: null,
    z: null
  });

  const [hasOrientationPermission, setHasOrientationPermission] = useState<boolean | null>(null);
  const [hasMotionPermission, setHasMotionPermission] = useState<boolean | null>(null);

  const requestPermissions = useCallback(async () => {
    if (typeof DeviceOrientationEvent !== 'undefined') {
      try {
        // For iOS 13+ we need to request permission
        if ('requestPermission' in DeviceOrientationEvent) {
          const permission = await (DeviceOrientationEvent as any).requestPermission();
          setHasOrientationPermission(permission === 'granted');
        } else {
          setHasOrientationPermission(true);
        }
      } catch (error) {
        console.error('Error requesting device orientation permission:', error);
        setHasOrientationPermission(false);
      }
    }

    if (typeof DeviceMotionEvent !== 'undefined') {
      try {
        // For iOS 13+ we need to request permission
        if ('requestPermission' in DeviceMotionEvent) {
          const permission = await (DeviceMotionEvent as any).requestPermission();
          setHasMotionPermission(permission === 'granted');
        } else {
          setHasMotionPermission(true);
        }
      } catch (error) {
        console.error('Error requesting device motion permission:', error);
        setHasMotionPermission(false);
      }
    }
  }, []);

  useEffect(() => {
    const handleOrientation = (event: DeviceOrientationEvent) => {
      setOrientation({
        alpha: event.alpha,
        beta: event.beta,
        gamma: event.gamma
      });
    };

    const handleMotion = (event: DeviceMotionEvent) => {
      const acceleration = event.acceleration;
      if (acceleration) {
        setMotion({
          x: acceleration.x,
          y: acceleration.y,
          z: acceleration.z
        });
      }
    };

    if (hasOrientationPermission === true) {
      window.addEventListener('deviceorientation', handleOrientation);
    }

    if (hasMotionPermission === true) {
      window.addEventListener('devicemotion', handleMotion);
    }

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation);
      window.removeEventListener('devicemotion', handleMotion);
    };
  }, [hasOrientationPermission, hasMotionPermission]);

  const getOrientationStatus = () => {
    if (hasOrientationPermission === null) return 'UNKNOWN';
    if (hasOrientationPermission === false) return 'DENIED';
    if (orientation.alpha !== null || orientation.beta !== null || orientation.gamma !== null) {
      return 'ACTIVE';
    }
    return 'STABLE';
  };

  const getMotionStatus = () => {
    if (hasMotionPermission === null) return 'UNKNOWN';
    if (hasMotionPermission === false) return 'DENIED';
    if (motion.x !== null || motion.y !== null || motion.z !== null) {
      return 'DETECTING';
    }
    return 'MONITORING';
  };

  return {
    orientation,
    motion,
    hasOrientationPermission,
    hasMotionPermission,
    requestPermissions,
    getOrientationStatus,
    getMotionStatus
  };
}
