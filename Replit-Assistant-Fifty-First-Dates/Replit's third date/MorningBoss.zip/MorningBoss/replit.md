# Machine_Touched Laboratory - Cybernetic Art Installation

## Overview
An interactive web-based art installation that demonstrates invisible human-machine symbiosis through sensor-based web technologies. Users experience cybernetic connection without physical attachments - the machine reads their digital body language through mouse movements, device sensors, and behavioral patterns.

## Recent Changes (September 15, 2025)
- Initial build completed with full cyberpunk laboratory interface
- Successful test of visual aesthetic and UI components
- All main panels functional: Biometric Analysis, Symbiosis Detector, Specimen Tracker, Proximity Sensors, Data Streams, System Logs
- Neural pathway canvas with particle effects implemented
- WebSocket real-time communication established
- Dark theme with matrix-style glow effects working properly

## Project Architecture
**Frontend:** React SPA with Wouter routing, TypeScript, Tailwind CSS, shadcn/ui components
**Backend:** Express.js with WebSocket support for real-time biometric streaming  
**Storage:** In-memory storage with specimen database and biometric data tracking
**Sensors:** Device motion/orientation APIs, mouse tracking, behavioral pattern analysis
**Visual:** HTML5 Canvas for neural pathway animations, CSS animations for cyberpunk effects

## Art Concept: "Two Parts Called a Whole Part"
Demonstrates that humans and computers are already cybernetically linked through:
- Mouse velocity and hesitation patterns revealing thought processes
- Device orientation showing physical proximity and engagement  
- Click rhythms indicating neural state
- Ambient data streams showing unconscious digital communication
- Real-time symbiosis level calculation based on interaction patterns

## Testing Progress
- ✅ Cyberpunk aesthetic and responsive layout
- ⏳ Neural canvas particle generation (pending)
- ⏳ Biometric tracking accuracy (pending) 
- ⏳ Symbiosis detector percentage calculation (pending)
- ⏳ Device sensor integration (pending)
- ⏳ WebSocket real-time streaming (pending)
- ⏳ Dynamic data stream updates (pending)

## Deployment Options
**Replit Hosting:** Use "Publish" button → Autoscale Deployment → Add custom domain
**External Hosting:** Export all files - compatible with any static hosting service

## Known Issues
- 3 minor TypeScript type compatibility warnings in server/storage.ts (non-blocking)
- WebSocket handshake warnings in development (functionality not impacted)

## User Preferences
- Focus on the "computer part of the plotline" - demonstrating cybernetic attachment through sensors rather than physical implants
- Machine_Touched aesthetic with specimen tracking and laboratory environment
- Interactive art experience that makes visitors realize they're already cyborgs through their digital body language