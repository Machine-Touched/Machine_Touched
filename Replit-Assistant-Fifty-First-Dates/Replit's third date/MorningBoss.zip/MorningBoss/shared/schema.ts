import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, real, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const specimens = pgTable("specimens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  specimenId: text("specimen_id").notNull().unique(),
  classification: text("classification").notNull(),
  status: text("status").notNull(), // ACTIVE, DORMANT, SCANNING
  lastDetected: timestamp("last_detected").defaultNow(),
  behaviorData: jsonb("behavior_data").$type<{
    mouseVelocity?: number;
    hesitationTime?: number;
    clickPattern?: string;
    symbiosisLevel?: number;
  }>(),
});

export const biometricData = pgTable("biometric_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: text("session_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  mouseVelocity: real("mouse_velocity"),
  hesitationTime: real("hesitation_time"),
  clickPattern: text("click_pattern"),
  symbiosisLevel: real("symbiosis_level"),
  pathwayCount: integer("pathway_count"),
  deviceOrientation: jsonb("device_orientation").$type<{
    alpha?: number;
    beta?: number;
    gamma?: number;
  }>(),
  deviceMotion: jsonb("device_motion").$type<{
    x?: number;
    y?: number;
    z?: number;
  }>(),
});

export const systemLogs = pgTable("system_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").defaultNow(),
  level: text("level").notNull(), // INFO, WARNING, ERROR
  message: text("message").notNull(),
  component: text("component").notNull(),
});

export const insertSpecimenSchema = createInsertSchema(specimens).omit({
  id: true,
  lastDetected: true,
});

export const insertBiometricDataSchema = createInsertSchema(biometricData).omit({
  id: true,
  timestamp: true,
});

export const insertSystemLogSchema = createInsertSchema(systemLogs).omit({
  id: true,
  timestamp: true,
});

export type InsertSpecimen = z.infer<typeof insertSpecimenSchema>;
export type Specimen = typeof specimens.$inferSelect;

export type InsertBiometricData = z.infer<typeof insertBiometricDataSchema>;
export type BiometricData = typeof biometricData.$inferSelect;

export type InsertSystemLog = z.infer<typeof insertSystemLogSchema>;
export type SystemLog = typeof systemLogs.$inferSelect;
