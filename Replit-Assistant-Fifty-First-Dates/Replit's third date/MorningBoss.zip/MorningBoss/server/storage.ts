import { type Specimen, type InsertSpecimen, type BiometricData, type InsertBiometricData, type SystemLog, type InsertSystemLog } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Specimen methods
  getSpecimen(id: string): Promise<Specimen | undefined>;
  getAllSpecimens(): Promise<Specimen[]>;
  createSpecimen(specimen: InsertSpecimen): Promise<Specimen>;
  updateSpecimen(id: string, updates: Partial<Specimen>): Promise<Specimen | undefined>;

  // Biometric data methods
  saveBiometricData(data: InsertBiometricData): Promise<BiometricData>;
  getBiometricDataBySession(sessionId: string): Promise<BiometricData[]>;
  getLatestBiometricData(sessionId: string): Promise<BiometricData | undefined>;

  // System logs methods
  addSystemLog(log: InsertSystemLog): Promise<SystemLog>;
  getRecentSystemLogs(limit?: number): Promise<SystemLog[]>;
}

export class MemStorage implements IStorage {
  private specimens: Map<string, Specimen>;
  private biometricData: Map<string, BiometricData>;
  private systemLogs: SystemLog[];

  constructor() {
    this.specimens = new Map();
    this.biometricData = new Map();
    this.systemLogs = [];
    
    // Initialize with some default specimens
    this.initializeSpecimens();
  }

  private initializeSpecimens() {
    const defaultSpecimens = [
      { specimenId: "SP-001", classification: "DIGITAL_CLOTHING_LOUSE", status: "ACTIVE" },
      { specimenId: "SP-002", classification: "DATA_PARASITE", status: "DORMANT" },
      { specimenId: "SP-003", classification: "NEURAL_SYMBIONT", status: "ACTIVE" },
      { specimenId: "SP-004", classification: "CYBER_ORGANISM", status: "SCANNING" },
    ];

    defaultSpecimens.forEach(spec => {
      this.createSpecimen(spec);
    });
  }

  async getSpecimen(id: string): Promise<Specimen | undefined> {
    return this.specimens.get(id);
  }

  async getAllSpecimens(): Promise<Specimen[]> {
    return Array.from(this.specimens.values());
  }

  async createSpecimen(insertSpecimen: InsertSpecimen): Promise<Specimen> {
    const id = randomUUID();
    const specimen: Specimen = {
      ...insertSpecimen,
      id,
      lastDetected: new Date(),
      behaviorData: insertSpecimen.behaviorData || null
    };
    this.specimens.set(id, specimen);
    return specimen;
  }

  async updateSpecimen(id: string, updates: Partial<Specimen>): Promise<Specimen | undefined> {
    const existing = this.specimens.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.specimens.set(id, updated);
    return updated;
  }

  async saveBiometricData(insertData: InsertBiometricData): Promise<BiometricData> {
    const id = randomUUID();
    const data: BiometricData = {
      ...insertData,
      id,
      timestamp: new Date(),
      deviceOrientation: insertData.deviceOrientation || null,
      deviceMotion: insertData.deviceMotion || null
    };
    this.biometricData.set(id, data);
    return data;
  }

  async getBiometricDataBySession(sessionId: string): Promise<BiometricData[]> {
    return Array.from(this.biometricData.values())
      .filter(data => data.sessionId === sessionId)
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0));
  }

  async getLatestBiometricData(sessionId: string): Promise<BiometricData | undefined> {
    const sessionData = await this.getBiometricDataBySession(sessionId);
    return sessionData[0];
  }

  async addSystemLog(insertLog: InsertSystemLog): Promise<SystemLog> {
    const id = randomUUID();
    const log: SystemLog = {
      ...insertLog,
      id,
      timestamp: new Date()
    };
    this.systemLogs.push(log);
    
    // Keep only last 100 logs
    if (this.systemLogs.length > 100) {
      this.systemLogs = this.systemLogs.slice(-100);
    }
    
    return log;
  }

  async getRecentSystemLogs(limit: number = 10): Promise<SystemLog[]> {
    return this.systemLogs
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
