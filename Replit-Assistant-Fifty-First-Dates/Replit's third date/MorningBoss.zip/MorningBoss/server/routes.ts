import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertBiometricDataSchema, insertSystemLogSchema } from "@shared/schema";
import { randomUUID } from "crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // REST API Routes
  app.get("/api/specimens", async (req, res) => {
    try {
      const specimens = await storage.getAllSpecimens();
      res.json(specimens);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch specimens" });
    }
  });

  app.get("/api/specimens/:id", async (req, res) => {
    try {
      const specimen = await storage.getSpecimen(req.params.id);
      if (!specimen) {
        return res.status(404).json({ message: "Specimen not found" });
      }
      res.json(specimen);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch specimen" });
    }
  });

  app.post("/api/biometric-data", async (req, res) => {
    try {
      const validatedData = insertBiometricDataSchema.parse(req.body);
      const savedData = await storage.saveBiometricData(validatedData);
      res.json(savedData);
    } catch (error) {
      res.status(400).json({ message: "Invalid biometric data" });
    }
  });

  app.get("/api/biometric-data/:sessionId", async (req, res) => {
    try {
      const data = await storage.getBiometricDataBySession(req.params.sessionId);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch biometric data" });
    }
  });

  app.get("/api/system-logs", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const logs = await storage.getRecentSystemLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch system logs" });
    }
  });

  app.post("/api/system-logs", async (req, res) => {
    try {
      const validatedLog = insertSystemLogSchema.parse(req.body);
      const savedLog = await storage.addSystemLog(validatedLog);
      res.json(savedLog);
    } catch (error) {
      res.status(400).json({ message: "Invalid log data" });
    }
  });

  // WebSocket Server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  interface ClientConnection {
    ws: WebSocket;
    sessionId: string;
    lastHeartbeat: number;
  }

  const clients = new Map<string, ClientConnection>();

  wss.on('connection', (ws) => {
    const sessionId = randomUUID();
    const clientConnection: ClientConnection = {
      ws,
      sessionId,
      lastHeartbeat: Date.now()
    };
    
    clients.set(sessionId, clientConnection);
    
    // Send initial connection message
    ws.send(JSON.stringify({
      type: 'connected',
      sessionId,
      message: 'Machine_Touch Laboratory: Neural link established'
    }));

    // Log connection
    storage.addSystemLog({
      level: 'INFO',
      message: `Neural connection established: ${sessionId}`,
      component: 'WebSocket'
    });

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'heartbeat':
            clientConnection.lastHeartbeat = Date.now();
            ws.send(JSON.stringify({ type: 'heartbeat_ack' }));
            break;
            
          case 'biometric_update':
            // Save biometric data
            await storage.saveBiometricData({
              sessionId,
              ...data.payload
            });
            
            // Broadcast to other clients
            broadcastToOthers(sessionId, {
              type: 'biometric_broadcast',
              sessionId,
              data: data.payload
            });
            break;
            
          case 'specimen_interaction':
            // Log specimen interaction
            await storage.addSystemLog({
              level: 'INFO',
              message: `Specimen interaction: ${data.payload.specimenId}`,
              component: 'Specimen_Tracker'
            });
            
            // Broadcast specimen update
            broadcast({
              type: 'specimen_update',
              data: data.payload
            });
            break;
            
          case 'system_status':
            // Broadcast system status update
            broadcast({
              type: 'status_update',
              data: data.payload
            });
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(sessionId);
      storage.addSystemLog({
        level: 'INFO',
        message: `Neural connection terminated: ${sessionId}`,
        component: 'WebSocket'
      });
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(sessionId);
    });
  });

  function broadcast(message: any) {
    clients.forEach((client) => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    });
  }

  function broadcastToOthers(excludeSessionId: string, message: any) {
    clients.forEach((client, sessionId) => {
      if (sessionId !== excludeSessionId && client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    });
  }

  // Periodic cleanup of stale connections
  setInterval(() => {
    const now = Date.now();
    clients.forEach((client, sessionId) => {
      if (now - client.lastHeartbeat > 60000) { // 1 minute timeout
        client.ws.close();
        clients.delete(sessionId);
      }
    });
  }, 30000); // Check every 30 seconds

  return httpServer;
}
